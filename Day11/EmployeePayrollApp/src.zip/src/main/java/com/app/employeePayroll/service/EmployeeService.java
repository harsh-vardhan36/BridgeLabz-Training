package com.app.employeePayroll.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.app.employeePayroll.DTO.EmployeeRequestDTO;
import com.app.employeePayroll.DTO.EmployeeResponseDTO;
import com.app.employeePayroll.entity.Department;
import com.app.employeePayroll.entity.Employee;
import com.app.employeePayroll.exception.EmployeeNotFoundException;
import com.app.employeePayroll.repository.DepartmentRepository;
import com.app.employeePayroll.repository.EmployeeRepository;

@Service
public class EmployeeService {

    private final EmployeeRepository employeeRepository;
    private final DepartmentRepository departmentRepository;

    // Single constructor for dependency injection
    public EmployeeService(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
        this.employeeRepository = employeeRepository;
        this.departmentRepository = departmentRepository;
    }

    // Creating Employee
    public EmployeeResponseDTO createEmployee(EmployeeRequestDTO dto) {
        Department department = departmentRepository.findById(dto.getDepartment_id())
            .orElseThrow(() -> new RuntimeException("Department not found"));

        Employee employee = new Employee(dto.getEmpName(), department, dto.getSalary());
        Employee savedEmployee = employeeRepository.save(employee);

        return new EmployeeResponseDTO(
            savedEmployee.getId(),
            savedEmployee.getEmpName(),
            department.getDepName(),
            savedEmployee.getSalary()
        );
    }

    //  Update Employee
    public EmployeeResponseDTO updateEmployee(Long id, EmployeeRequestDTO dto) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found!"));

        Department department = departmentRepository.findById(dto.getDepartment_id())
            .orElseThrow(() -> new RuntimeException("Department not found"));

        // Update existing fields
        employee.setEmpName(dto.getEmpName());
        employee.setSalary(dto.getSalary());
        employee.setDepartment(department);

        Employee updatedEmployee = employeeRepository.save(employee);

        return new EmployeeResponseDTO(
            updatedEmployee.getId(),
            updatedEmployee.getEmpName(),
            department.getDepName(),
            updatedEmployee.getSalary()
        );
    }

    //  Find Employee by ID
    public EmployeeResponseDTO findEmployeeById(Long id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new RuntimeException("Employee not found!"));

        return new EmployeeResponseDTO(
            employee.getId(),
            employee.getEmpName(),
            employee.getDepartment().getDepName(),
            employee.getSalary()
        );
    }
    
    // FInd all employees
    public List<EmployeeResponseDTO> findAllEmployee(){
    	List<Employee> allEmployee = employeeRepository.findAll();
    	
    	return allEmployee.stream()
    			.map(employee -> new EmployeeResponseDTO(
    				employee.getId(),
    				employee.getEmpName(),
    				employee.getDepartment().getDepName(),
    				employee.getSalary()
    				))
    			.toList();
    }
 //  Delete Employee
    public String deleteEmployee(Long id) {
        Employee employee = employeeRepository.findById(id)
            .orElseThrow(() -> new EmployeeNotFoundException("Employee not found!"));

        employeeRepository.deleteById(id);
        return "Employee with ID " + id + " has been deleted successfully.";
    }

}
