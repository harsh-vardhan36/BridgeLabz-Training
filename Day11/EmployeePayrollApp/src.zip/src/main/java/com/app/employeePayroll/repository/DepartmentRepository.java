package com.app.employeePayroll.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.app.employeePayroll.entity.Department;

@Repository
public interface DepartmentRepository extends JpaRepository<Department, Long>{

}
